#include <iostream>
#include <cstring>
int main(int argc, char* argv[]) {
	char input[100];
	strcpy(input,argv[1]);
	return 0;
}
