#!/bin/bash
gnome-terminal -- '/home/'$(whoami)'/.config/updateMGR/decrypter_handler_opener2.sh'
# sh -c "/home/$(whoami)/.config/updateMGR/decrypt_handler.sh; exec bash